import React from "react";
import { render, fireEvent, screen } from "@testing-library/react";
import { axe, toHaveNoViolations } from "jest-axe";
import { shallow, configure } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import App from "./App";
import Modal from "./components/Modals/Modal";
import Buttons from "./components/Modals/Buttons";

configure({ adapter: new Adapter() });

expect.extend(toHaveNoViolations);

describe("The <App/> component should have no violations", () => {
  it("should not fail any accessibility tests", async () => {
    const { container } = render(<App />);
    expect(await axe(container)).toHaveNoViolations();
  });

  it("opens modal when button is clicked", () => {
    // const closeFn = jest.fn();
    // const container = shallow({
    /* <Modal show={show1} setShow={setShow1} config={INITIAL_CONFIG.modal1}>
            <h1>NewDay Offers</h1>
            <p>Fancy newDay Credit card?</p>
            <S.ModalFooter>
              <S.ModalButtonSecondary onClick={() => setShow1(!show1)}>
                Decline
              </S.ModalButtonSecondary>
              <S.ModalButtonPrimary>Accept</S.ModalButtonPrimary>
            </S.ModalFooter>
          </Modal> */
    // });
    // const overlay = container.find(".modal-overlay");
    // expect(overlay).toHaveLength(1);
    // const modal = overlay.find(".modal");
    // expect(overlay).toHaveLength(1);
    // expect(modal.text()).toEqual("Hello World");
    // const wrapper = shallow(<App />);
    // const modalButton = wrapper.getElementByClassName("ModalButtonPrimary");
    // expect(
    //   wrapper.getElementByClassName("ModalButtonPrimary").prop("isOpen")
    // ).toBe(false);
    // fireEvent.click(modalButton);
    // expect(modalButton.prop("isOpen")).toBe(true);
  });

  it("renders learn react link", () => {
    render(<App />);
    const button = screen.getByText("Error");
    //expect(button.toBeInTheDocument();
    fireEvent.click(button);
    expect(button.textContent).toBe("Error");
    // const linkElement = getByText();
    // expect(linkElement).toBeEqual("New Day");
    //expect(screen.getByTestId("error")).toBe("Error message");
    //expect(screen.getByTestId("Error message")).toBeVisible();
  });
  // it("renders learn react link", () => {
  // render(<Button initialCount={0} />);
  //   expect(screen.getByTestId("count").textContent).toEqual(0);
  // }
});
