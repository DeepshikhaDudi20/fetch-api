import { createGlobalStyle } from "styled-components";

export const GlobalStyles = createGlobalStyle`
  body {
    background: ${({ theme }) => theme.body};
    color: ${({ theme }) => theme.text};
    transition: background 0.2s ease-in, color 0.2s ease-in;
  }
`;

//aqua
export const auqaTheme = {
  body: "#EDEDED",
  text: "#000",
  colors: {
    main: "#0000a6",
    shadowMain: "#9d2744",
    btnText: "#fff",
    dark: "#0000a6"
  }
};
//OPUS IS DARK
export const opusTheme = {
  body: "#EDEDED",
  text: "#000",
  colors: {
    main: "#007680",
    shadowMain: "#9d2744",
    btnText: "#fff",
    dark: "#007680"
  }
};
