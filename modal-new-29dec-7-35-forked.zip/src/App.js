import { useState } from "react";
import Header from "./shared/components/layout/Header";
import { Buttons, Modal } from "./shared/components/Modals";

import { ThemeProvider } from "styled-components";
import { opusTheme, aquaTheme, GlobalStyles } from "./styles/theme";

import * as S from "./shared/components/Modals/styles";
import { Modal_Content } from "./App_Data/Modal-data";

const App = () => {
  const [theme, setTheme] = useState("opus");
  const [show1, setShow1] = useState(false);
  const [show2, setShow2] = useState(false);
  const [show3, setShow3] = useState(false);
  const [show4, setShow4] = useState(false);

  const isOpusTheme = theme === "opus";

  return (
    <ThemeProvider theme={isOpusTheme ? opusTheme : aquaTheme}>
      <>
        <GlobalStyles />
        <Header isOpusTheme={isOpusTheme} setTheme={setTheme} />
        <main>
          <Buttons
            show1={show1}
            setShow1={setShow1}
            show2={show2}
            setShow2={setShow2}
            show3={show3}
            setShow3={setShow3}
            show4={show4}
            setShow4={setShow4}
            data-testid="button"
          />

          <Modal
            show={show1}
            setShow={setShow1}
            config={Modal_Content.confirmationModal}
            data-test-id="offer"
          >
            <h1>NewDay Offers</h1>
            <p>Fancy newDay Credit card?</p>
            <S.ModalFooter>
              <S.ModalButtonSecondary onClick={() => setShow1(!show1)}>
                Decline
              </S.ModalButtonSecondary>
              <S.ModalButtonPrimary>Accept</S.ModalButtonPrimary>
            </S.ModalFooter>
          </Modal>

          <Modal
            show={show2}
            setShow={setShow2}
            config={Modal_Content.subscribeModal}
          >
            <p>Want to subscribe to newsletter?</p>
            <input type="email" placeholder="Please input your email" />
            <S.ModalFooter>
              <S.ModalButtonPrimary>Subscribe</S.ModalButtonPrimary>
            </S.ModalFooter>
          </Modal>

          <Modal
            show={show4}
            setShow={setShow4}
            config={Modal_Content.infoModal}
            data-testid="error"
          >
            <h1>Side Modal</h1>
            <p>Error message</p>
          </Modal>
        </main>
      </>
    </ThemeProvider>
  );
};

export default App;
