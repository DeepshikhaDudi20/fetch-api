export const ModalPositionX = {
  center: "center",
  right: "right",
  left: "left"
};

export const ModalPositionY = {
  center: "center",
  start: "start",
  end: "end"
};
