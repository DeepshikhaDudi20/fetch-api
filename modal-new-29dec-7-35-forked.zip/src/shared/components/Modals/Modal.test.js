import React from "react";
import { render, fireEvent, screen } from "@testing-library/react";
import renderer from "react-test-renderer";
import { axe, toHaveNoViolations } from "jest-axe";
import { shallow } from "enzyme";
import Modal from "./Modal";

expect.extend(toHaveNoViolations);
const onClick = jest.fn();
describe("The <Modal/> component testing", () => {
  it("should not fail any accessibility tests", async () => {
    const { container } = render(<Modal />);
    expect(await axe(container)).toHaveNoViolations();
  });

  // it("renders react-modal", () => {
  //   const wrapper = shallow(<Modal />);
  //   expect(wrapper.find(Modal)).toHaveLength(1);
  // });

  //   // it("should render Modal component elements", () => {
  //   //   const elem = renderer.create(<Modal />).toJSON();
  //   //   expect(elem).toMatchSnapshot();
  //   // });
});
