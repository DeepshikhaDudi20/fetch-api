import * as S from "./styles";

const Buttons = ({
  setShow1,
  show1,
  setShow2,
  show2,
  setShow3,
  show3,
  setShow4,
  show4
}) => {
  return (
    <S.ModalButtonsContainer>
      <S.ModalButtonPrimary onClick={() => setShow1(!show1)}>
        Fancy newDay Credit card?
      </S.ModalButtonPrimary>
      <S.ModalButtonPrimary onClick={() => setShow2(!show2)}>
        Join Newletter
      </S.ModalButtonPrimary>
      <S.ModalButtonPrimary onClick={() => setShow4(!show4)}>
        Error
      </S.ModalButtonPrimary>
    </S.ModalButtonsContainer>
  );
};

export default Buttons;
