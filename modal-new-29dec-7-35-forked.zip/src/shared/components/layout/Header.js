import * as HeaderStyles from "./styles";

const Header = ({ isOpusTheme, setTheme }) => {
  debugger;
  const toggleTheme = () => setTheme(isOpusTheme ? "opus" : "aqua");
  return (
    <HeaderStyles.Header>
      <HeaderStyles.HeaderContainer>
        <HeaderStyles.ButtonSecondary onClick={toggleTheme}>
          {isOpusTheme ? (
            <span aria-label="Opus mode">Opus Theme</span>
          ) : (
            <span aria-label="Aqua mode">Aqua Theme</span>
          )}
        </HeaderStyles.ButtonSecondary>
      </HeaderStyles.HeaderContainer>
    </HeaderStyles.Header>
  );
};

export default Header;
